import { Filter, Search, SlidersHorizontal } from "lucide-react"
import Image from "next/image"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Badge } from "@/components/ui/badge"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"

export default function MarketplacePage() {
  // Sample equipment data
  const equipment = [
    {
      id: 1,
      name: "John Deere 5E Series Tractor",
      category: "Tractors",
      price: 1250000,
      condition: "New",
      location: "Punjab",
      image: "/placeholder.svg?height=200&width=300",
      seller: "Agro Machinery Ltd",
      verified: true,
    },
    {
      id: 2,
      name: "Mahindra 575 DI Tractor",
      category: "Tractors",
      price: 750000,
      condition: "Used",
      location: "Haryana",
      image: "/placeholder.svg?height=200&width=300",
      seller: "Farm Equipment Store",
      verified: true,
    },
    {
      id: 3,
      name: "Rotavator 5 Feet",
      category: "Implements",
      price: 85000,
      condition: "New",
      location: "Uttar Pradesh",
      image: "/placeholder.svg?height=200&width=300",
      seller: "Agri Implements",
      verified: true,
    },
    {
      id: 4,
      name: "Sprayer 100L Capacity",
      category: "Sprayers",
      price: 12000,
      condition: "New",
      location: "Maharashtra",
      image: "/placeholder.svg?height=200&width=300",
      seller: "Spray Tech Solutions",
      verified: false,
    },
    {
      id: 5,
      name: "Combine Harvester",
      category: "Harvesters",
      price: 1800000,
      condition: "Used",
      location: "Punjab",
      image: "/placeholder.svg?height=200&width=300",
      seller: "Harvest Solutions",
      verified: true,
    },
    {
      id: 6,
      name: "Seed Drill",
      category: "Seeders",
      price: 120000,
      condition: "New",
      location: "Gujarat",
      image: "/placeholder.svg?height=200&width=300",
      seller: "Seeding Experts",
      verified: true,
    },
  ]

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <div className="bg-green-700 text-white py-8">
        <div className="container mx-auto px-4">
          <h1 className="text-3xl font-bold mb-2">Equipment Marketplace</h1>
          <p className="text-green-100">Find the right agricultural equipment for your farm</p>
        </div>
      </div>

      <div className="container mx-auto px-4 py-8">
        {/* Search and Filter Bar */}
        <div className="bg-white rounded-lg shadow-md p-4 mb-8">
          <div className="flex flex-col md:flex-row gap-4">
            <div className="relative flex-grow">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground h-4 w-4" />
              <Input placeholder="Search for equipment..." className="pl-10" />
            </div>
            <div className="flex flex-wrap gap-2">
              <Select>
                <SelectTrigger className="w-[150px]">
                  <SelectValue placeholder="Category" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Categories</SelectItem>
                  <SelectItem value="tractors">Tractors</SelectItem>
                  <SelectItem value="implements">Implements</SelectItem>
                  <SelectItem value="harvesters">Harvesters</SelectItem>
                  <SelectItem value="sprayers">Sprayers</SelectItem>
                  <SelectItem value="seeders">Seeders</SelectItem>
                </SelectContent>
              </Select>

              <Select>
                <SelectTrigger className="w-[150px]">
                  <SelectValue placeholder="Condition" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Conditions</SelectItem>
                  <SelectItem value="new">New</SelectItem>
                  <SelectItem value="used">Used</SelectItem>
                </SelectContent>
              </Select>

              <Select>
                <SelectTrigger className="w-[150px]">
                  <SelectValue placeholder="Location" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Locations</SelectItem>
                  <SelectItem value="punjab">Punjab</SelectItem>
                  <SelectItem value="haryana">Haryana</SelectItem>
                  <SelectItem value="up">Uttar Pradesh</SelectItem>
                  <SelectItem value="maharashtra">Maharashtra</SelectItem>
                  <SelectItem value="gujarat">Gujarat</SelectItem>
                </SelectContent>
              </Select>

              <Button variant="outline" className="flex items-center gap-2">
                <SlidersHorizontal className="h-4 w-4" />
                More Filters
              </Button>
            </div>
          </div>
        </div>

        {/* Main Content */}
        <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
          {/* Sidebar Filters */}
          <div className="hidden lg:block">
            <div className="bg-white rounded-lg shadow-md p-4">
              <h3 className="font-semibold text-lg mb-4 flex items-center">
                <Filter className="mr-2 h-5 w-5" />
                Filters
              </h3>

              <div className="space-y-6">
                <div>
                  <h4 className="font-medium mb-2">Price Range</h4>
                  <div className="grid grid-cols-2 gap-2">
                    <Input placeholder="Min" type="number" />
                    <Input placeholder="Max" type="number" />
                  </div>
                </div>

                <div>
                  <h4 className="font-medium mb-2">Brand</h4>
                  <div className="space-y-2">
                    {["John Deere", "Mahindra", "Sonalika", "New Holland", "Massey Ferguson"].map((brand) => (
                      <div key={brand} className="flex items-center">
                        <input type="checkbox" id={brand} className="mr-2" />
                        <label htmlFor={brand}>{brand}</label>
                      </div>
                    ))}
                  </div>
                </div>

                <div>
                  <h4 className="font-medium mb-2">Year</h4>
                  <div className="space-y-2">
                    {["2023-2024", "2020-2022", "2015-2019", "2010-2014", "Before 2010"].map((year) => (
                      <div key={year} className="flex items-center">
                        <input type="checkbox" id={year} className="mr-2" />
                        <label htmlFor={year}>{year}</label>
                      </div>
                    ))}
                  </div>
                </div>

                <div>
                  <h4 className="font-medium mb-2">Seller Type</h4>
                  <div className="space-y-2">
                    {["Verified Dealer", "Individual Seller", "Manufacturer"].map((type) => (
                      <div key={type} className="flex items-center">
                        <input type="checkbox" id={type} className="mr-2" />
                        <label htmlFor={type}>{type}</label>
                      </div>
                    ))}
                  </div>
                </div>

                <Button className="w-full">Apply Filters</Button>
              </div>
            </div>
          </div>

          {/* Equipment Listings */}
          <div className="lg:col-span-3">
            <Tabs defaultValue="all">
              <div className="flex justify-between items-center mb-6">
                <TabsList>
                  <TabsTrigger value="all">All Equipment</TabsTrigger>
                  <TabsTrigger value="new">New</TabsTrigger>
                  <TabsTrigger value="used">Used</TabsTrigger>
                </TabsList>

                <Select defaultValue="recommended">
                  <SelectTrigger className="w-[180px]">
                    <SelectValue placeholder="Sort By" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="recommended">Recommended</SelectItem>
                    <SelectItem value="price-low">Price: Low to High</SelectItem>
                    <SelectItem value="price-high">Price: High to Low</SelectItem>
                    <SelectItem value="newest">Newest First</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <TabsContent value="all" className="mt-0">
                <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-6">
                  {equipment.map((item) => (
                    <Card key={item.id} className="overflow-hidden">
                      <div className="relative">
                        <Image
                          src={item.image || "/placeholder.svg"}
                          alt={item.name}
                          width={300}
                          height={200}
                          className="w-full h-48 object-cover"
                        />
                        <Badge className="absolute top-2 right-2 bg-white text-black">{item.condition}</Badge>
                      </div>
                      <CardHeader className="pb-2">
                        <div className="flex justify-between items-start">
                          <CardTitle className="text-lg">{item.name}</CardTitle>
                          {item.verified && (
                            <Badge variant="outline" className="text-green-600 border-green-600">
                              Verified
                            </Badge>
                          )}
                        </div>
                      </CardHeader>
                      <CardContent className="pb-2">
                        <div className="flex justify-between text-sm text-muted-foreground mb-2">
                          <span>{item.category}</span>
                          <span>{item.location}</span>
                        </div>
                        <div className="text-xl font-bold">₹{item.price.toLocaleString()}</div>
                        <div className="text-sm text-muted-foreground">Seller: {item.seller}</div>
                      </CardContent>
                      <CardFooter className="flex gap-2">
                        <Button className="flex-1">View Details</Button>
                        <Button variant="outline" className="flex-1">
                          Contact Seller
                        </Button>
                      </CardFooter>
                    </Card>
                  ))}
                </div>
              </TabsContent>

              <TabsContent value="new" className="mt-0">
                <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-6">
                  {equipment
                    .filter((item) => item.condition === "New")
                    .map((item) => (
                      <Card key={item.id} className="overflow-hidden">
                        <div className="relative">
                          <Image
                            src={item.image || "/placeholder.svg"}
                            alt={item.name}
                            width={300}
                            height={200}
                            className="w-full h-48 object-cover"
                          />
                          <Badge className="absolute top-2 right-2 bg-white text-black">{item.condition}</Badge>
                        </div>
                        <CardHeader className="pb-2">
                          <div className="flex justify-between items-start">
                            <CardTitle className="text-lg">{item.name}</CardTitle>
                            {item.verified && (
                              <Badge variant="outline" className="text-green-600 border-green-600">
                                Verified
                              </Badge>
                            )}
                          </div>
                        </CardHeader>
                        <CardContent className="pb-2">
                          <div className="flex justify-between text-sm text-muted-foreground mb-2">
                            <span>{item.category}</span>
                            <span>{item.location}</span>
                          </div>
                          <div className="text-xl font-bold">₹{item.price.toLocaleString()}</div>
                          <div className="text-sm text-muted-foreground">Seller: {item.seller}</div>
                        </CardContent>
                        <CardFooter className="flex gap-2">
                          <Button className="flex-1">View Details</Button>
                          <Button variant="outline" className="flex-1">
                            Contact Seller
                          </Button>
                        </CardFooter>
                      </Card>
                    ))}
                </div>
              </TabsContent>

              <TabsContent value="used" className="mt-0">
                <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-6">
                  {equipment
                    .filter((item) => item.condition === "Used")
                    .map((item) => (
                      <Card key={item.id} className="overflow-hidden">
                        <div className="relative">
                          <Image
                            src={item.image || "/placeholder.svg"}
                            alt={item.name}
                            width={300}
                            height={200}
                            className="w-full h-48 object-cover"
                          />
                          <Badge className="absolute top-2 right-2 bg-white text-black">{item.condition}</Badge>
                        </div>
                        <CardHeader className="pb-2">
                          <div className="flex justify-between items-start">
                            <CardTitle className="text-lg">{item.name}</CardTitle>
                            {item.verified && (
                              <Badge variant="outline" className="text-green-600 border-green-600">
                                Verified
                              </Badge>
                            )}
                          </div>
                        </CardHeader>
                        <CardContent className="pb-2">
                          <div className="flex justify-between text-sm text-muted-foreground mb-2">
                            <span>{item.category}</span>
                            <span>{item.location}</span>
                          </div>
                          <div className="text-xl font-bold">₹{item.price.toLocaleString()}</div>
                          <div className="text-sm text-muted-foreground">Seller: {item.seller}</div>
                        </CardContent>
                        <CardFooter className="flex gap-2">
                          <Button className="flex-1">View Details</Button>
                          <Button variant="outline" className="flex-1">
                            Contact Seller
                          </Button>
                        </CardFooter>
                      </Card>
                    ))}
                </div>
              </TabsContent>
            </Tabs>

            {/* Pagination */}
            <div className="flex justify-center mt-8">
              <div className="flex items-center gap-1">
                <Button variant="outline" size="icon" disabled>
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    width="24"
                    height="24"
                    viewBox="0 0 24 24"
                    fill="none"
                    stroke="currentColor"
                    strokeWidth="2"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    className="h-4 w-4"
                  >
                    <path d="m15 18-6-6 6-6" />
                  </svg>
                </Button>
                <Button variant="outline" size="sm" className="bg-primary text-primary-foreground">
                  1
                </Button>
                <Button variant="outline" size="sm">
                  2
                </Button>
                <Button variant="outline" size="sm">
                  3
                </Button>
                <Button variant="outline" size="sm">
                  4
                </Button>
                <Button variant="outline" size="sm">
                  5
                </Button>
                <Button variant="outline" size="icon">
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    width="24"
                    height="24"
                    viewBox="0 0 24 24"
                    fill="none"
                    stroke="currentColor"
                    strokeWidth="2"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    className="h-4 w-4"
                  >
                    <path d="m9 18 6-6-6-6" />
                  </svg>
                </Button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}

