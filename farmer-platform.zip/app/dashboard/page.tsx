import {
  ArrowUpRight,
  Calendar,
  ChevronRight,
  Clock,
  CreditCard,
  DollarSign,
  FileText,
  HelpCircle,
  MessageSquare,
  Package,
  ShoppingCart,
  Tractor,
  Users,
} from "lucide-react"
import Image from "next/image"
import Link from "next/link"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Progress } from "@/components/ui/progress"
import { Badge } from "@/components/ui/badge"

export default function DashboardPage() {
  return (
    <div className="min-h-screen bg-muted/50">
      <div className="container mx-auto px-4 py-8">
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-8 gap-4">
          <div>
            <h1 className="text-3xl font-bold">Dashboard</h1>
            <p className="text-muted-foreground">Welcome back, Ramesh! Here's what's happening with your farm.</p>
          </div>
          <div className="flex gap-2">
            <Button variant="outline">
              <HelpCircle className="mr-2 h-4 w-4" />
              Help
            </Button>
            <Button>
              <ShoppingCart className="mr-2 h-4 w-4" />
              Shop Now
            </Button>
          </div>
        </div>

        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between pb-2">
              <CardTitle className="text-sm font-medium">Total Equipment</CardTitle>
              <Tractor className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">12</div>
              <p className="text-xs text-muted-foreground">+2 from last month</p>
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="flex flex-row items-center justify-between pb-2">
              <CardTitle className="text-sm font-medium">Active Schemes</CardTitle>
              <FileText className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">3</div>
              <p className="text-xs text-muted-foreground">1 pending approval</p>
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="flex flex-row items-center justify-between pb-2">
              <CardTitle className="text-sm font-medium">Consultations</CardTitle>
              <Users className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">8</div>
              <p className="text-xs text-muted-foreground">2 scheduled this week</p>
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="flex flex-row items-center justify-between pb-2">
              <CardTitle className="text-sm font-medium">Total Savings</CardTitle>
              <DollarSign className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">₹45,231</div>
              <p className="text-xs text-muted-foreground">Through schemes and discounts</p>
            </CardContent>
          </Card>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Main Content */}
          <div className="lg:col-span-2 space-y-8">
            {/* Recent Orders */}
            <Card>
              <CardHeader>
                <div className="flex justify-between items-center">
                  <CardTitle>Recent Orders</CardTitle>
                  <Button variant="ghost" size="sm" className="gap-1">
                    View All
                    <ChevronRight className="h-4 w-4" />
                  </Button>
                </div>
                <CardDescription>Your recent equipment purchases and rentals</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {[
                    {
                      id: "ORD-7652",
                      name: "Tractor Attachment - Rotavator",
                      date: "Mar 15, 2023",
                      amount: "₹24,500",
                      status: "Delivered",
                    },
                    {
                      id: "ORD-7321",
                      name: "Sprayer Pump 2HP",
                      date: "Feb 28, 2023",
                      amount: "₹8,750",
                      status: "Processing",
                    },
                    {
                      id: "ORD-6998",
                      name: "Seed Drill",
                      date: "Jan 12, 2023",
                      amount: "₹35,000",
                      status: "Delivered",
                    },
                  ].map((order) => (
                    <div
                      key={order.id}
                      className="flex items-center justify-between border-b pb-4 last:border-0 last:pb-0"
                    >
                      <div className="flex items-center gap-4">
                        <div className="bg-muted rounded-md p-2">
                          <Package className="h-5 w-5" />
                        </div>
                        <div>
                          <p className="font-medium">{order.name}</p>
                          <div className="flex items-center gap-2 text-sm text-muted-foreground">
                            <span>{order.id}</span>
                            <span>•</span>
                            <span>{order.date}</span>
                          </div>
                        </div>
                      </div>
                      <div className="flex items-center gap-4">
                        <span className="font-medium">{order.amount}</span>
                        <Badge variant={order.status === "Delivered" ? "outline" : "secondary"}>{order.status}</Badge>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            {/* Scheme Applications */}
            <Card>
              <CardHeader>
                <div className="flex justify-between items-center">
                  <CardTitle>Scheme Applications</CardTitle>
                  <Button variant="ghost" size="sm" className="gap-1">
                    View All
                    <ChevronRight className="h-4 w-4" />
                  </Button>
                </div>
                <CardDescription>Status of your government scheme applications</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-6">
                  {[
                    {
                      name: "PM-KISAN",
                      date: "Applied on Jan 10, 2023",
                      status: "Approved",
                      progress: 100,
                      amount: "₹6,000",
                      nextStep: "Next installment due in 2 months",
                    },
                    {
                      name: "Kisan Credit Card",
                      date: "Applied on Feb 5, 2023",
                      status: "Processing",
                      progress: 60,
                      amount: "₹1,60,000",
                      nextStep: "Bank verification pending",
                    },
                    {
                      name: "Subsidy for Drip Irrigation",
                      date: "Applied on Mar 1, 2023",
                      status: "Document Verification",
                      progress: 30,
                      amount: "₹25,000",
                      nextStep: "Field verification scheduled",
                    },
                  ].map((scheme) => (
                    <div key={scheme.name} className="space-y-2">
                      <div className="flex justify-between items-start">
                        <div>
                          <h4 className="font-medium">{scheme.name}</h4>
                          <p className="text-sm text-muted-foreground">{scheme.date}</p>
                        </div>
                        <Badge variant={scheme.status === "Approved" ? "outline" : "secondary"}>{scheme.status}</Badge>
                      </div>
                      <div className="space-y-1">
                        <div className="flex justify-between text-sm">
                          <span>Progress</span>
                          <span>{scheme.progress}%</span>
                        </div>
                        <Progress value={scheme.progress} className="h-2" />
                      </div>
                      <div className="flex justify-between text-sm">
                        <span>
                          Amount: <span className="font-medium">{scheme.amount}</span>
                        </span>
                        <span className="text-muted-foreground">{scheme.nextStep}</span>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Sidebar */}
          <div className="space-y-8">
            {/* Upcoming Consultations */}
            <Card>
              <CardHeader>
                <CardTitle>Upcoming Consultations</CardTitle>
                <CardDescription>Your scheduled expert consultations</CardDescription>
              </CardHeader>
              <CardContent className="space-y-5">
                {[
                  {
                    expert: "Dr. Rajesh Kumar",
                    specialization: "Crop Science",
                    date: "Today",
                    time: "2:00 PM",
                    image: "/placeholder.svg?height=50&width=50",
                  },
                  {
                    expert: "Anita Sharma",
                    specialization: "Organic Farming",
                    date: "Tomorrow",
                    time: "11:30 AM",
                    image: "/placeholder.svg?height=50&width=50",
                  },
                ].map((consultation, index) => (
                  <div key={index} className="flex gap-4 items-start">
                    <Image
                      src={consultation.image || "/placeholder.svg"}
                      alt={consultation.expert}
                      width={50}
                      height={50}
                      className="rounded-full"
                    />
                    <div className="flex-1">
                      <h4 className="font-medium">{consultation.expert}</h4>
                      <p className="text-sm text-muted-foreground">{consultation.specialization}</p>
                      <div className="flex items-center gap-4 mt-2 text-sm">
                        <div className="flex items-center">
                          <Calendar className="h-4 w-4 mr-1 text-muted-foreground" />
                          {consultation.date}
                        </div>
                        <div className="flex items-center">
                          <Clock className="h-4 w-4 mr-1 text-muted-foreground" />
                          {consultation.time}
                        </div>
                      </div>
                    </div>
                    <Button variant="outline" size="sm">
                      <MessageSquare className="h-4 w-4" />
                    </Button>
                  </div>
                ))}
                <Button variant="outline" className="w-full">
                  Schedule New Consultation
                </Button>
              </CardContent>
            </Card>

            {/* Payment Methods */}
            <Card>
              <CardHeader>
                <CardTitle>Payment Methods</CardTitle>
                <CardDescription>Manage your payment options</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex items-center justify-between border rounded-lg p-3">
                  <div className="flex items-center gap-3">
                    <CreditCard className="h-5 w-5" />
                    <div>
                      <p className="font-medium">•••• 4242</p>
                      <p className="text-xs text-muted-foreground">Expires 04/2025</p>
                    </div>
                  </div>
                  <Badge>Default</Badge>
                </div>
                <div className="flex items-center justify-between border rounded-lg p-3">
                  <div className="flex items-center gap-3">
                    <CreditCard className="h-5 w-5" />
                    <div>
                      <p className="font-medium">•••• 6789</p>
                      <p className="text-xs text-muted-foreground">Expires 09/2024</p>
                    </div>
                  </div>
                </div>
                <Button variant="outline" className="w-full">
                  Add Payment Method
                </Button>
              </CardContent>
            </Card>

            {/* Recommended Resources */}
            <Card>
              <CardHeader>
                <CardTitle>Recommended Resources</CardTitle>
                <CardDescription>Based on your farming profile</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                {[
                  {
                    title: "Organic Pest Management Techniques",
                    type: "Article",
                    time: "5 min read",
                  },
                  {
                    title: "Maximizing Crop Yield in Low Rainfall Areas",
                    type: "Video",
                    time: "12 min watch",
                  },
                  {
                    title: "New Subsidy Programs for Small Farmers",
                    type: "Guide",
                    time: "8 min read",
                  },
                ].map((resource, index) => (
                  <Link href="#" key={index} className="flex items-start gap-3 group">
                    <div className="bg-muted rounded-md p-2 mt-1">
                      <FileText className="h-4 w-4" />
                    </div>
                    <div className="flex-1">
                      <h4 className="font-medium group-hover:text-primary transition-colors">{resource.title}</h4>
                      <div className="flex items-center gap-2 text-xs text-muted-foreground">
                        <span>{resource.type}</span>
                        <span>•</span>
                        <span>{resource.time}</span>
                      </div>
                    </div>
                    <ArrowUpRight className="h-4 w-4 opacity-0 group-hover:opacity-100 transition-opacity" />
                  </Link>
                ))}
                <Button variant="ghost" className="w-full">
                  View All Resources
                </Button>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  )
}

