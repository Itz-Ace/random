import Link from "next/link"
import Image from "next/image"
import { ArrowRight, Tractor, FileText, Users, ChevronRight } from "lucide-react"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"

export default function Home() {
  return (
    <div className="flex flex-col min-h-screen">
      {/* Hero Section */}
      <header className="bg-gradient-to-r from-green-600 to-green-800 text-white">
        <div className="container mx-auto px-4 py-16 md:py-24">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8 items-center">
            <div className="space-y-6">
              <h1 className="text-4xl md:text-5xl font-bold tracking-tight">Empowering Farmers with Modern Tools</h1>
              <p className="text-lg md:text-xl text-green-100">
                Connect with equipment vendors, discover government schemes, and get expert agricultural advice all in
                one place.
              </p>
              <div className="flex flex-col sm:flex-row gap-4">
                <Button size="lg" className="bg-white text-green-800 hover:bg-green-100">
                  Get Started
                  <ArrowRight className="ml-2 h-5 w-5" />
                </Button>
                <Button size="lg" variant="outline" className="border-white text-white hover:bg-white/20">
                  Learn More
                </Button>
              </div>
            </div>
            <div className="hidden md:block">
              <Image
                src="/placeholder.svg?height=400&width=500"
                alt="Farming illustration"
                width={500}
                height={400}
                className="rounded-lg shadow-lg"
              />
            </div>
          </div>
        </div>
      </header>

      {/* Features Section */}
      <section className="py-16 bg-background">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold mb-4">Our Platform Features</h2>
            <p className="text-muted-foreground max-w-2xl mx-auto">
              Everything you need to optimize your farming operations and increase profitability
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <Card className="border-t-4 border-t-green-600">
              <CardHeader>
                <Tractor className="h-10 w-10 text-green-600 mb-2" />
                <CardTitle>Equipment Marketplace</CardTitle>
                <CardDescription>Buy and sell agricultural machinery from verified vendors</CardDescription>
              </CardHeader>
              <CardContent>
                <p>
                  Access a wide range of new and used farming equipment at competitive prices. All vendors are verified
                  for your safety.
                </p>
              </CardContent>
              <CardFooter>
                <Link
                  href="/marketplace"
                  className="text-green-600 hover:text-green-700 font-medium inline-flex items-center"
                >
                  Browse Equipment
                  <ChevronRight className="ml-1 h-4 w-4" />
                </Link>
              </CardFooter>
            </Card>

            <Card className="border-t-4 border-t-blue-600">
              <CardHeader>
                <FileText className="h-10 w-10 text-blue-600 mb-2" />
                <CardTitle>Government Scheme Navigator</CardTitle>
                <CardDescription>Discover and apply for agricultural subsidies and loans</CardDescription>
              </CardHeader>
              <CardContent>
                <p>
                  Answer a simple questionnaire to find government schemes you're eligible for, with direct application
                  links.
                </p>
              </CardContent>
              <CardFooter>
                <Link
                  href="/schemes"
                  className="text-blue-600 hover:text-blue-700 font-medium inline-flex items-center"
                >
                  Check Eligibility
                  <ChevronRight className="ml-1 h-4 w-4" />
                </Link>
              </CardFooter>
            </Card>

            <Card className="border-t-4 border-t-amber-600">
              <CardHeader>
                <Users className="h-10 w-10 text-amber-600 mb-2" />
                <CardTitle>Expert Connect</CardTitle>
                <CardDescription>Consult with agricultural experts for personalized advice</CardDescription>
              </CardHeader>
              <CardContent>
                <p>
                  Connect with BSc Agriculture students, experienced farmers, and agronomists to solve your farming
                  challenges.
                </p>
              </CardContent>
              <CardFooter>
                <Link
                  href="/experts"
                  className="text-amber-600 hover:text-amber-700 font-medium inline-flex items-center"
                >
                  Find an Expert
                  <ChevronRight className="ml-1 h-4 w-4" />
                </Link>
              </CardFooter>
            </Card>
          </div>
        </div>
      </section>

      {/* How It Works */}
      <section className="py-16 bg-muted/50">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold mb-4">How It Works</h2>
            <p className="text-muted-foreground max-w-2xl mx-auto">
              Our platform is designed to be simple and intuitive for farmers of all technical backgrounds
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            <div className="text-center">
              <div className="bg-green-100 text-green-800 rounded-full w-12 h-12 flex items-center justify-center mx-auto mb-4 text-xl font-bold">
                1
              </div>
              <h3 className="font-semibold text-lg mb-2">Sign Up</h3>
              <p className="text-muted-foreground">Create your account with basic information about your farm</p>
            </div>

            <div className="text-center">
              <div className="bg-green-100 text-green-800 rounded-full w-12 h-12 flex items-center justify-center mx-auto mb-4 text-xl font-bold">
                2
              </div>
              <h3 className="font-semibold text-lg mb-2">Explore Features</h3>
              <p className="text-muted-foreground">
                Browse equipment, check scheme eligibility, or connect with experts
              </p>
            </div>

            <div className="text-center">
              <div className="bg-green-100 text-green-800 rounded-full w-12 h-12 flex items-center justify-center mx-auto mb-4 text-xl font-bold">
                3
              </div>
              <h3 className="font-semibold text-lg mb-2">Take Action</h3>
              <p className="text-muted-foreground">Purchase equipment, apply for schemes, or book consultations</p>
            </div>

            <div className="text-center">
              <div className="bg-green-100 text-green-800 rounded-full w-12 h-12 flex items-center justify-center mx-auto mb-4 text-xl font-bold">
                4
              </div>
              <h3 className="font-semibold text-lg mb-2">Track Progress</h3>
              <p className="text-muted-foreground">
                Monitor your orders, applications, and consultations from your dashboard
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-16 bg-green-700 text-white">
        <div className="container mx-auto px-4 text-center">
          <h2 className="text-3xl font-bold mb-4">Ready to Transform Your Farming Experience?</h2>
          <p className="text-green-100 max-w-2xl mx-auto mb-8">
            Join thousands of farmers who are already benefiting from our platform's tools and resources.
          </p>
          <Button size="lg" className="bg-white text-green-800 hover:bg-green-100">
            Get Started Now
          </Button>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-gray-900 text-gray-300 py-12">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            <div>
              <h3 className="text-white text-lg font-semibold mb-4">FarmConnect</h3>
              <p className="text-sm">
                Empowering farmers with modern tools and resources to optimize their operations and increase
                profitability.
              </p>
            </div>
            <div>
              <h4 className="text-white text-base font-medium mb-4">Features</h4>
              <ul className="space-y-2 text-sm">
                <li>
                  <Link href="/marketplace" className="hover:text-white">
                    Equipment Marketplace
                  </Link>
                </li>
                <li>
                  <Link href="/schemes" className="hover:text-white">
                    Government Schemes
                  </Link>
                </li>
                <li>
                  <Link href="/experts" className="hover:text-white">
                    Expert Connect
                  </Link>
                </li>
                <li>
                  <Link href="/resources" className="hover:text-white">
                    Learning Resources
                  </Link>
                </li>
              </ul>
            </div>
            <div>
              <h4 className="text-white text-base font-medium mb-4">Company</h4>
              <ul className="space-y-2 text-sm">
                <li>
                  <Link href="/about" className="hover:text-white">
                    About Us
                  </Link>
                </li>
                <li>
                  <Link href="/contact" className="hover:text-white">
                    Contact
                  </Link>
                </li>
                <li>
                  <Link href="/careers" className="hover:text-white">
                    Careers
                  </Link>
                </li>
                <li>
                  <Link href="/blog" className="hover:text-white">
                    Blog
                  </Link>
                </li>
              </ul>
            </div>
            <div>
              <h4 className="text-white text-base font-medium mb-4">Legal</h4>
              <ul className="space-y-2 text-sm">
                <li>
                  <Link href="/terms" className="hover:text-white">
                    Terms of Service
                  </Link>
                </li>
                <li>
                  <Link href="/privacy" className="hover:text-white">
                    Privacy Policy
                  </Link>
                </li>
                <li>
                  <Link href="/cookies" className="hover:text-white">
                    Cookie Policy
                  </Link>
                </li>
              </ul>
            </div>
          </div>
          <div className="border-t border-gray-800 mt-8 pt-8 text-sm text-center">
            <p>© {new Date().getFullYear()} FarmConnect. All rights reserved.</p>
          </div>
        </div>
      </footer>
    </div>
  )
}

