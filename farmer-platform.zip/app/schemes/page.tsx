import { ArrowRight, CheckCircle2, FileText, Info } from "lucide-react"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Progress } from "@/components/ui/progress"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Badge } from "@/components/ui/badge"
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion"

export default function SchemesPage() {
  // Sample schemes data
  const schemes = [
    {
      id: 1,
      name: "PM-KISAN",
      description: "Income support of ₹6,000 per year in three equal installments to all land holding farmer families",
      category: "Financial Support",
      eligibility: ["All landholding farmers", "Subject to exclusion criteria"],
      benefits: "₹6,000 per year",
      deadline: "Ongoing",
      agency: "Ministry of Agriculture & Farmers Welfare",
    },
    {
      id: 2,
      name: "Kisan Credit Card",
      description: "Provides farmers with affordable credit for their agricultural needs",
      category: "Credit",
      eligibility: ["All farmers", "Tenant farmers", "Oral lessees", "SHGs"],
      benefits: "Credit up to ₹3 lakh at 7% interest rate",
      deadline: "Ongoing",
      agency: "NABARD & Banking Institutions",
    },
    {
      id: 3,
      name: "Pradhan Mantri Fasal Bima Yojana",
      description: "Crop insurance scheme to provide financial support to farmers suffering crop loss/damage",
      category: "Insurance",
      eligibility: ["All farmers growing notified crops", "Both loanee and non-loanee farmers"],
      benefits: "Insurance coverage and financial support",
      deadline: "Seasonal application",
      agency: "Ministry of Agriculture & Farmers Welfare",
    },
    {
      id: 4,
      name: "Agriculture Infrastructure Fund",
      description: "Financing facility for investment in agriculture infrastructure projects",
      category: "Infrastructure",
      eligibility: ["Farmers", "FPOs", "PACS", "Agri-entrepreneurs", "Startups"],
      benefits: "₹1 lakh crore financing facility with interest subvention",
      deadline: "2020-2029",
      agency: "Ministry of Agriculture & Farmers Welfare",
    },
    {
      id: 5,
      name: "National Mission for Sustainable Agriculture",
      description: "Promotes sustainable agriculture through climate change adaptation measures",
      category: "Sustainable Farming",
      eligibility: ["All farmers", "Special focus on rainfed areas"],
      benefits: "Subsidies for micro-irrigation, soil health management",
      deadline: "Ongoing",
      agency: "Ministry of Agriculture & Farmers Welfare",
    },
    {
      id: 6,
      name: "Sub-Mission on Agricultural Mechanization",
      description:
        "Promotes farm mechanization and increases the reach of farm machinery to small and marginal farmers",
      category: "Mechanization",
      eligibility: ["Individual farmers", "Group of farmers", "Cooperative societies"],
      benefits: "Subsidy up to 50% on purchase of agricultural machinery",
      deadline: "Ongoing",
      agency: "Department of Agriculture & Cooperation",
    },
  ]

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <div className="bg-blue-700 text-white py-8">
        <div className="container mx-auto px-4">
          <h1 className="text-3xl font-bold mb-2">Government Scheme Navigator</h1>
          <p className="text-blue-100">Find and apply for agricultural subsidies, loans, and schemes</p>
        </div>
      </div>

      <div className="container mx-auto px-4 py-8">
        {/* Eligibility Checker */}
        <Card className="mb-8">
          <CardHeader>
            <CardTitle className="text-2xl">Check Your Eligibility</CardTitle>
            <CardDescription>Answer a few questions to find schemes you're eligible for</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="mb-6">
              <div className="flex justify-between mb-2">
                <span className="text-sm font-medium">Questionnaire Progress</span>
                <span className="text-sm font-medium">2 of 5 completed</span>
              </div>
              <Progress value={40} className="h-2" />
            </div>

            <div className="space-y-6">
              <div className="border rounded-lg p-4">
                <h3 className="font-medium mb-3">Question 3: What type of farming do you practice?</h3>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <Button variant="outline" className="justify-start h-auto py-3 px-4">
                    <div className="flex flex-col items-start text-left">
                      <span className="font-medium">Crop Farming</span>
                      <span className="text-sm text-muted-foreground">Growing grains, vegetables, fruits, etc.</span>
                    </div>
                  </Button>
                  <Button variant="outline" className="justify-start h-auto py-3 px-4">
                    <div className="flex flex-col items-start text-left">
                      <span className="font-medium">Livestock Farming</span>
                      <span className="text-sm text-muted-foreground">Raising animals for dairy, meat, etc.</span>
                    </div>
                  </Button>
                  <Button variant="outline" className="justify-start h-auto py-3 px-4">
                    <div className="flex flex-col items-start text-left">
                      <span className="font-medium">Mixed Farming</span>
                      <span className="text-sm text-muted-foreground">Both crop and livestock farming</span>
                    </div>
                  </Button>
                  <Button variant="outline" className="justify-start h-auto py-3 px-4">
                    <div className="flex flex-col items-start text-left">
                      <span className="font-medium">Organic Farming</span>
                      <span className="text-sm text-muted-foreground">Without synthetic inputs</span>
                    </div>
                  </Button>
                </div>
              </div>

              <div className="flex justify-between">
                <Button variant="outline">Previous</Button>
                <Button>
                  Next Question
                  <ArrowRight className="ml-2 h-4 w-4" />
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Schemes Listing */}
        <div className="mb-8">
          <h2 className="text-2xl font-bold mb-6">Available Agricultural Schemes</h2>

          <Tabs defaultValue="all">
            <TabsList className="mb-6">
              <TabsTrigger value="all">All Schemes</TabsTrigger>
              <TabsTrigger value="financial">Financial Support</TabsTrigger>
              <TabsTrigger value="credit">Credit</TabsTrigger>
              <TabsTrigger value="insurance">Insurance</TabsTrigger>
              <TabsTrigger value="infrastructure">Infrastructure</TabsTrigger>
            </TabsList>

            <TabsContent value="all" className="mt-0">
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {schemes.map((scheme) => (
                  <Card key={scheme.id} className="flex flex-col">
                    <CardHeader>
                      <div className="flex justify-between items-start">
                        <CardTitle>{scheme.name}</CardTitle>
                        <Badge>{scheme.category}</Badge>
                      </div>
                      <CardDescription>{scheme.description}</CardDescription>
                    </CardHeader>
                    <CardContent className="flex-grow">
                      <div className="space-y-2">
                        <div className="flex items-start gap-2">
                          <Info className="h-4 w-4 text-blue-600 mt-1 shrink-0" />
                          <div>
                            <span className="font-medium block">Benefits:</span>
                            <span>{scheme.benefits}</span>
                          </div>
                        </div>
                        <div className="flex items-start gap-2">
                          <CheckCircle2 className="h-4 w-4 text-green-600 mt-1 shrink-0" />
                          <div>
                            <span className="font-medium block">Eligibility:</span>
                            <ul className="list-disc list-inside pl-1">
                              {scheme.eligibility.map((item, index) => (
                                <li key={index} className="text-sm">
                                  {item}
                                </li>
                              ))}
                            </ul>
                          </div>
                        </div>
                        <div className="flex items-start gap-2">
                          <FileText className="h-4 w-4 text-orange-600 mt-1 shrink-0" />
                          <div>
                            <span className="font-medium block">Agency:</span>
                            <span className="text-sm">{scheme.agency}</span>
                          </div>
                        </div>
                      </div>
                    </CardContent>
                    <CardFooter className="border-t pt-4 mt-auto">
                      <div className="flex justify-between items-center w-full">
                        <span className="text-sm">
                          <span className="font-medium">Deadline:</span> {scheme.deadline}
                        </span>
                        <Button>Apply Now</Button>
                      </div>
                    </CardFooter>
                  </Card>
                ))}
              </div>
            </TabsContent>

            <TabsContent value="financial" className="mt-0">
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {schemes
                  .filter((scheme) => scheme.category === "Financial Support")
                  .map((scheme) => (
                    <Card key={scheme.id} className="flex flex-col">
                      <CardHeader>
                        <div className="flex justify-between items-start">
                          <CardTitle>{scheme.name}</CardTitle>
                          <Badge>{scheme.category}</Badge>
                        </div>
                        <CardDescription>{scheme.description}</CardDescription>
                      </CardHeader>
                      <CardContent className="flex-grow">
                        <div className="space-y-2">
                          <div className="flex items-start gap-2">
                            <Info className="h-4 w-4 text-blue-600 mt-1 shrink-0" />
                            <div>
                              <span className="font-medium block">Benefits:</span>
                              <span>{scheme.benefits}</span>
                            </div>
                          </div>
                          <div className="flex items-start gap-2">
                            <CheckCircle2 className="h-4 w-4 text-green-600 mt-1 shrink-0" />
                            <div>
                              <span className="font-medium block">Eligibility:</span>
                              <ul className="list-disc list-inside pl-1">
                                {scheme.eligibility.map((item, index) => (
                                  <li key={index} className="text-sm">
                                    {item}
                                  </li>
                                ))}
                              </ul>
                            </div>
                          </div>
                        </div>
                      </CardContent>
                      <CardFooter className="border-t pt-4 mt-auto">
                        <div className="flex justify-between items-center w-full">
                          <span className="text-sm">
                            <span className="font-medium">Deadline:</span> {scheme.deadline}
                          </span>
                          <Button>Apply Now</Button>
                        </div>
                      </CardFooter>
                    </Card>
                  ))}
              </div>
            </TabsContent>

            {/* Other tabs would follow the same pattern */}
          </Tabs>
        </div>

        {/* FAQ Section */}
        <div>
          <h2 className="text-2xl font-bold mb-6">Frequently Asked Questions</h2>

          <Accordion type="single" collapsible className="w-full">
            <AccordionItem value="item-1">
              <AccordionTrigger>How do I know which schemes I'm eligible for?</AccordionTrigger>
              <AccordionContent>
                You can use our Eligibility Checker tool above to answer a few questions about your farming situation.
                Based on your responses, we'll recommend schemes that match your profile. Alternatively, you can browse
                all schemes and check the eligibility criteria for each one.
              </AccordionContent>
            </AccordionItem>

            <AccordionItem value="item-2">
              <AccordionTrigger>What documents do I need to apply for agricultural schemes?</AccordionTrigger>
              <AccordionContent>
                Common documents required include proof of identity (Aadhaar card, voter ID), proof of land ownership
                (land records, khata copy), bank account details, passport-sized photographs, and income certificate.
                Specific schemes may require additional documents which will be listed in the application process.
              </AccordionContent>
            </AccordionItem>

            <AccordionItem value="item-3">
              <AccordionTrigger>How long does the application process take?</AccordionTrigger>
              <AccordionContent>
                Processing times vary by scheme. Simple subsidies may be approved within 2-4 weeks, while more complex
                loan or infrastructure schemes might take 1-3 months. Our platform provides real-time status updates for
                your applications so you can track their progress.
              </AccordionContent>
            </AccordionItem>

            <AccordionItem value="item-4">
              <AccordionTrigger>Can I apply for multiple schemes simultaneously?</AccordionTrigger>
              <AccordionContent>
                Yes, you can apply for multiple schemes as long as you meet the eligibility criteria for each. However,
                some schemes may have overlapping benefits or restrictions on combining with other programs. Our
                platform will notify you of any potential conflicts during the application process.
              </AccordionContent>
            </AccordionItem>

            <AccordionItem value="item-5">
              <AccordionTrigger>What if my application is rejected?</AccordionTrigger>
              <AccordionContent>
                If your application is rejected, you'll receive a notification with the reason. You can address the
                issues and reapply, or explore alternative schemes. Our support team is available to help you understand
                rejection reasons and improve your application for resubmission.
              </AccordionContent>
            </AccordionItem>
          </Accordion>
        </div>
      </div>
    </div>
  )
}

