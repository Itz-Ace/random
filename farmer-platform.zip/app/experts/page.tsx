import { Calendar, Clock, Filter, MessageSquare, Phone, Search, Star, Users } from "lucide-react"
import Image from "next/image"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Badge } from "@/components/ui/badge"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"

export default function ExpertsPage() {
  // Sample experts data
  const experts = [
    {
      id: 1,
      name: "Dr. Rajesh Kumar",
      title: "Agricultural Scientist",
      specialization: "Crop Science",
      experience: "15+ years",
      rating: 4.8,
      reviews: 124,
      image: "/placeholder.svg?height=200&width=200",
      availability: "Available today",
      languages: ["English", "Hindi", "Punjabi"],
      consultationFee: 1200,
      verified: true,
    },
    {
      id: 2,
      name: "Anita Sharma",
      title: "BSc Agriculture Graduate",
      specialization: "Organic Farming",
      experience: "5 years",
      rating: 4.6,
      reviews: 78,
      image: "/placeholder.svg?height=200&width=200",
      availability: "Available tomorrow",
      languages: ["English", "Hindi"],
      consultationFee: 800,
      verified: true,
    },
    {
      id: 3,
      name: "Suresh Patel",
      title: "Experienced Farmer",
      specialization: "Cotton & Groundnut",
      experience: "25+ years",
      rating: 4.9,
      reviews: 210,
      image: "/placeholder.svg?height=200&width=200",
      availability: "Available today",
      languages: ["Gujarati", "Hindi", "English"],
      consultationFee: 500,
      verified: true,
    },
    {
      id: 4,
      name: "Dr. Meena Reddy",
      title: "Agronomist",
      specialization: "Soil Health & Fertilizers",
      experience: "12 years",
      rating: 4.7,
      reviews: 95,
      image: "/placeholder.svg?height=200&width=200",
      availability: "Available in 2 days",
      languages: ["English", "Telugu", "Hindi"],
      consultationFee: 1500,
      verified: true,
    },
    {
      id: 5,
      name: "Vikram Singh",
      title: "Agricultural Engineer",
      specialization: "Farm Mechanization",
      experience: "8 years",
      rating: 4.5,
      reviews: 62,
      image: "/placeholder.svg?height=200&width=200",
      availability: "Available today",
      languages: ["English", "Hindi", "Punjabi"],
      consultationFee: 1000,
      verified: false,
    },
    {
      id: 6,
      name: "Priya Desai",
      title: "Plant Pathologist",
      specialization: "Pest & Disease Management",
      experience: "10 years",
      rating: 4.8,
      reviews: 87,
      image: "/placeholder.svg?height=200&width=200",
      availability: "Available tomorrow",
      languages: ["English", "Marathi", "Hindi"],
      consultationFee: 1200,
      verified: true,
    },
  ]

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <div className="bg-amber-700 text-white py-8">
        <div className="container mx-auto px-4">
          <h1 className="text-3xl font-bold mb-2">Expert Connect</h1>
          <p className="text-amber-100">Get personalized advice from agricultural experts</p>
        </div>
      </div>

      <div className="container mx-auto px-4 py-8">
        {/* Search and Filter Bar */}
        <div className="bg-white rounded-lg shadow-md p-4 mb-8">
          <div className="flex flex-col md:flex-row gap-4">
            <div className="relative flex-grow">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground h-4 w-4" />
              <Input placeholder="Search by name, specialization..." className="pl-10" />
            </div>
            <div className="flex flex-wrap gap-2">
              <Select>
                <SelectTrigger className="w-[180px]">
                  <SelectValue placeholder="Specialization" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Specializations</SelectItem>
                  <SelectItem value="crop">Crop Science</SelectItem>
                  <SelectItem value="organic">Organic Farming</SelectItem>
                  <SelectItem value="soil">Soil Health</SelectItem>
                  <SelectItem value="mechanization">Farm Mechanization</SelectItem>
                  <SelectItem value="pest">Pest Management</SelectItem>
                </SelectContent>
              </Select>

              <Select>
                <SelectTrigger className="w-[180px]">
                  <SelectValue placeholder="Availability" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">Any Time</SelectItem>
                  <SelectItem value="today">Available Today</SelectItem>
                  <SelectItem value="tomorrow">Available Tomorrow</SelectItem>
                  <SelectItem value="week">This Week</SelectItem>
                </SelectContent>
              </Select>

              <Select>
                <SelectTrigger className="w-[180px]">
                  <SelectValue placeholder="Language" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Languages</SelectItem>
                  <SelectItem value="english">English</SelectItem>
                  <SelectItem value="hindi">Hindi</SelectItem>
                  <SelectItem value="punjabi">Punjabi</SelectItem>
                  <SelectItem value="gujarati">Gujarati</SelectItem>
                  <SelectItem value="marathi">Marathi</SelectItem>
                  <SelectItem value="telugu">Telugu</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
        </div>

        {/* Main Content */}
        <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
          {/* Sidebar Filters */}
          <div className="hidden lg:block">
            <div className="bg-white rounded-lg shadow-md p-4">
              <h3 className="font-semibold text-lg mb-4 flex items-center">
                <Filter className="mr-2 h-5 w-5" />
                Filters
              </h3>

              <div className="space-y-6">
                <div>
                  <h4 className="font-medium mb-2">Expert Type</h4>
                  <div className="space-y-2">
                    {[
                      "Agricultural Scientists",
                      "Agronomists",
                      "Experienced Farmers",
                      "Agriculture Graduates",
                      "Agricultural Engineers",
                    ].map((type) => (
                      <div key={type} className="flex items-center">
                        <input type="checkbox" id={type} className="mr-2" />
                        <label htmlFor={type}>{type}</label>
                      </div>
                    ))}
                  </div>
                </div>

                <div>
                  <h4 className="font-medium mb-2">Experience</h4>
                  <div className="space-y-2">
                    {["Less than 5 years", "5-10 years", "10-15 years", "15+ years"].map((exp) => (
                      <div key={exp} className="flex items-center">
                        <input type="checkbox" id={exp} className="mr-2" />
                        <label htmlFor={exp}>{exp}</label>
                      </div>
                    ))}
                  </div>
                </div>

                <div>
                  <h4 className="font-medium mb-2">Consultation Fee</h4>
                  <div className="space-y-2">
                    {["Under ₹500", "₹500-₹1000", "₹1000-₹1500", "Above ₹1500"].map((fee) => (
                      <div key={fee} className="flex items-center">
                        <input type="checkbox" id={fee} className="mr-2" />
                        <label htmlFor={fee}>{fee}</label>
                      </div>
                    ))}
                  </div>
                </div>

                <div>
                  <h4 className="font-medium mb-2">Rating</h4>
                  <div className="space-y-2">
                    {["4.5 & above", "4.0 & above", "3.5 & above", "3.0 & above"].map((rating) => (
                      <div key={rating} className="flex items-center">
                        <input type="checkbox" id={rating} className="mr-2" />
                        <label htmlFor={rating}>{rating}</label>
                      </div>
                    ))}
                  </div>
                </div>

                <Button className="w-full">Apply Filters</Button>
              </div>
            </div>
          </div>

          {/* Experts Listings */}
          <div className="lg:col-span-3">
            <Tabs defaultValue="all">
              <div className="flex justify-between items-center mb-6">
                <TabsList>
                  <TabsTrigger value="all">All Experts</TabsTrigger>
                  <TabsTrigger value="scientists">Scientists</TabsTrigger>
                  <TabsTrigger value="farmers">Farmers</TabsTrigger>
                  <TabsTrigger value="engineers">Engineers</TabsTrigger>
                </TabsList>

                <Select defaultValue="rating">
                  <SelectTrigger className="w-[180px]">
                    <SelectValue placeholder="Sort By" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="rating">Highest Rated</SelectItem>
                    <SelectItem value="reviews">Most Reviews</SelectItem>
                    <SelectItem value="fee-low">Fee: Low to High</SelectItem>
                    <SelectItem value="fee-high">Fee: High to Low</SelectItem>
                    <SelectItem value="experience">Most Experienced</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <TabsContent value="all" className="mt-0">
                <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-6">
                  {experts.map((expert) => (
                    <Card key={expert.id} className="overflow-hidden">
                      <CardHeader className="pb-2">
                        <div className="flex gap-4">
                          <Image
                            src={expert.image || "/placeholder.svg"}
                            alt={expert.name}
                            width={80}
                            height={80}
                            className="rounded-full h-20 w-20 object-cover"
                          />
                          <div>
                            <div className="flex items-center gap-2">
                              <CardTitle className="text-lg">{expert.name}</CardTitle>
                              {expert.verified && (
                                <Badge variant="outline" className="text-green-600 border-green-600">
                                  Verified
                                </Badge>
                              )}
                            </div>
                            <CardDescription>{expert.title}</CardDescription>
                            <div className="flex items-center mt-1">
                              <Star className="h-4 w-4 fill-amber-500 text-amber-500" />
                              <span className="ml-1 font-medium">{expert.rating}</span>
                              <span className="text-muted-foreground ml-1">({expert.reviews} reviews)</span>
                            </div>
                          </div>
                        </div>
                      </CardHeader>
                      <CardContent className="pb-2">
                        <div className="space-y-2">
                          <div className="flex items-center text-sm">
                            <Users className="h-4 w-4 mr-2 text-muted-foreground" />
                            <span className="font-medium">Specialization:</span>
                            <span className="ml-1">{expert.specialization}</span>
                          </div>
                          <div className="flex items-center text-sm">
                            <Calendar className="h-4 w-4 mr-2 text-muted-foreground" />
                            <span className="font-medium">Experience:</span>
                            <span className="ml-1">{expert.experience}</span>
                          </div>
                          <div className="flex items-center text-sm">
                            <Clock className="h-4 w-4 mr-2 text-muted-foreground" />
                            <span className="text-green-600">{expert.availability}</span>
                          </div>
                          <div className="flex items-center text-sm">
                            <span className="font-medium">Languages:</span>
                            <span className="ml-1">{expert.languages.join(", ")}</span>
                          </div>
                          <div className="text-lg font-bold">
                            ₹{expert.consultationFee}{" "}
                            <span className="text-sm font-normal text-muted-foreground">per consultation</span>
                          </div>
                        </div>
                      </CardContent>
                      <CardFooter className="flex gap-2">
                        <Button className="flex-1">
                          <MessageSquare className="h-4 w-4 mr-2" />
                          Chat
                        </Button>
                        <Button variant="outline" className="flex-1">
                          <Phone className="h-4 w-4 mr-2" />
                          Call
                        </Button>
                      </CardFooter>
                    </Card>
                  ))}
                </div>
              </TabsContent>

              <TabsContent value="scientists" className="mt-0">
                <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-6">
                  {experts
                    .filter(
                      (expert) =>
                        expert.title.includes("Scientist") ||
                        expert.title.includes("Agronomist") ||
                        expert.title.includes("Pathologist"),
                    )
                    .map((expert) => (
                      <Card key={expert.id} className="overflow-hidden">
                        <CardHeader className="pb-2">
                          <div className="flex gap-4">
                            <Image
                              src={expert.image || "/placeholder.svg"}
                              alt={expert.name}
                              width={80}
                              height={80}
                              className="rounded-full h-20 w-20 object-cover"
                            />
                            <div>
                              <div className="flex items-center gap-2">
                                <CardTitle className="text-lg">{expert.name}</CardTitle>
                                {expert.verified && (
                                  <Badge variant="outline" className="text-green-600 border-green-600">
                                    Verified
                                  </Badge>
                                )}
                              </div>
                              <CardDescription>{expert.title}</CardDescription>
                              <div className="flex items-center mt-1">
                                <Star className="h-4 w-4 fill-amber-500 text-amber-500" />
                                <span className="ml-1 font-medium">{expert.rating}</span>
                                <span className="text-muted-foreground ml-1">({expert.reviews} reviews)</span>
                              </div>
                            </div>
                          </div>
                        </CardHeader>
                        <CardContent className="pb-2">
                          <div className="space-y-2">
                            <div className="flex items-center text-sm">
                              <Users className="h-4 w-4 mr-2 text-muted-foreground" />
                              <span className="font-medium">Specialization:</span>
                              <span className="ml-1">{expert.specialization}</span>
                            </div>
                            <div className="flex items-center text-sm">
                              <Calendar className="h-4 w-4 mr-2 text-muted-foreground" />
                              <span className="font-medium">Experience:</span>
                              <span className="ml-1">{expert.experience}</span>
                            </div>
                            <div className="flex items-center text-sm">
                              <Clock className="h-4 w-4 mr-2 text-muted-foreground" />
                              <span className="text-green-600">{expert.availability}</span>
                            </div>
                            <div className="text-lg font-bold">
                              ₹{expert.consultationFee}{" "}
                              <span className="text-sm font-normal text-muted-foreground">per consultation</span>
                            </div>
                          </div>
                        </CardContent>
                        <CardFooter className="flex gap-2">
                          <Button className="flex-1">
                            <MessageSquare className="h-4 w-4 mr-2" />
                            Chat
                          </Button>
                          <Button variant="outline" className="flex-1">
                            <Phone className="h-4 w-4 mr-2" />
                            Call
                          </Button>
                        </CardFooter>
                      </Card>
                    ))}
                </div>
              </TabsContent>

              {/* Other tabs would follow the same pattern */}
            </Tabs>

            {/* Pagination */}
            <div className="flex justify-center mt-8">
              <div className="flex items-center gap-1">
                <Button variant="outline" size="icon" disabled>
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    width="24"
                    height="24"
                    viewBox="0 0 24 24"
                    fill="none"
                    stroke="currentColor"
                    strokeWidth="2"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    className="h-4 w-4"
                  >
                    <path d="m15 18 6-6-6-6" />
                  </svg>
                </Button>
                <Button variant="outline" size="sm" className="bg-primary text-primary-foreground">
                  1
                </Button>
                <Button variant="outline" size="sm">
                  2
                </Button>
                <Button variant="outline" size="sm">
                  3
                </Button>
                <Button variant="outline" size="sm">
                  4
                </Button>
                <Button variant="outline" size="sm">
                  5
                </Button>
                <Button variant="outline" size="icon">
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    width="24"
                    height="24"
                    viewBox="0 0 24 24"
                    fill="none"
                    stroke="currentColor"
                    strokeWidth="2"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    className="h-4 w-4"
                  >
                    <path d="m9 18 6-6-6-6" />
                  </svg>
                </Button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}

